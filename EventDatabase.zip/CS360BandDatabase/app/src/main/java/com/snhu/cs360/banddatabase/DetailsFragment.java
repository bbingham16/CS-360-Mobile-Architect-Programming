package com.snhu.cs360.banddatabase;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import java.util.ArrayList;
import java.util.List;

public class DetailsFragment extends Fragment {

    private static final List<EventListener> listeners = new ArrayList<>();

    public interface EventListener {
        void handleEdited(Event original, Event edited);
        void handleDeleted(Event deleted);
    }

    private Event mEvent;

    // creating new instance
    public static DetailsFragment newInstance(int eventId) {
        DetailsFragment fragment = new DetailsFragment();
        Bundle args = new Bundle();
        args.putInt("eventId", eventId);
        fragment.setArguments(args);
        return fragment;
    }

    public static void register(EventListener listener){
        listeners.add(listener);
    }

    int setDateMonth;
    int setDateDay;
    int setDateYear;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Get the event ID from the intent that started DetailsActivity
        int eventId = 1;
        if (getArguments() != null) {
            eventId = getArguments().getInt("eventId");
        }
        mEvent = EventsDatabase.getInstance(getContext()).getEvent(eventId);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_details, container, false);

        // retrieving and displaying info for the Event Name
        TextView nameTextView = (TextView) view.findViewById(R.id.lblEventName);
        nameTextView.setText(mEvent.getName());

        // retrieving and displaying info for the Event description
        TextView descriptionTextView = (TextView) view.findViewById(R.id.eventDescription);
        descriptionTextView.setText(mEvent.getDescription());

        // retrieving and displaying info for the Event date
        TextView dateTextView = (TextView) view.findViewById(R.id.eventDate);
        dateTextView.setText(String.valueOf(mEvent.getDate()));

        Button btnEdit = view.findViewById(R.id.btnEdit);

        // listening if the edit button is pressed
        btnEdit.setOnClickListener(l -> {

            AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
            builder.setTitle("Edit Event Details");

            // setting the view to the edit event details dialog box
            View editView = inflater.inflate(R.layout.event_details, null);
            builder.setView(editView);

            // allowing the user to edit all the details of the event including using a DatePicker to select the date
            EditText txtDescription = editView.findViewById(R.id.txtDescription);
            txtDescription.setText(mEvent.getDescription());
            EditText txtName = editView.findViewById(R.id.txtName);
            txtName.setText(mEvent.getName());
            DatePicker txtDate = editView.findViewById(R.id.datePicker);

            //  Positive button created to save all edited/ updated info to the database
            builder.setPositiveButton("Ok", (dialogInterface, i) -> {
                String name = txtName.getText().toString();
                String description = txtDescription.getText().toString();
                setDateMonth = txtDate.getMonth();
                setDateDay = txtDate.getDayOfMonth();
                setDateYear = txtDate.getYear();
                String date = String.valueOf(setDateMonth + 1) + " - " +  String.valueOf(setDateDay) + " - " + String.valueOf(setDateYear);
                Event edited = new Event(mEvent.getId(), name, description, date);

                // getting the instance of the edited event ID to save all edited fields to the database
                boolean isEdited = EventsDatabase.getInstance(getContext()).editEvent(mEvent.getId(), edited);

                // Toast to print out if the event was not edited successfully
                if (!isEdited){
                    Toast.makeText(getContext(), "Error editing Event" +
                            "", Toast.LENGTH_SHORT).show();
                    // Saving edited fields to getters for each field.
                } else {
                    listeners.forEach(listener -> listener.handleEdited(mEvent, edited));
                    mEvent = edited;
                    nameTextView.setText(edited.getName());
                    descriptionTextView.setText(edited.getDescription());
                    dateTextView.setText(edited.getDate());
                }
            });

            // negative button to cancel editing the event and leave fields as they were entered previously.
            builder.setNegativeButton("Cancel", null);
            builder.create();

            builder.show();
        });
        // Delete button to delete the Event from the database
        Button btnDelete = view.findViewById(R.id.btnDelete);
        btnDelete.setOnClickListener(l -> {
            boolean isDeleted = EventsDatabase.getInstance(getContext()).deleteEvent(mEvent.getId());

            if (!isDeleted){
                Toast.makeText(getContext(), "Error deleting Event", Toast.LENGTH_SHORT).show();
            } else {
                listeners.forEach(listener -> listener.handleDeleted(mEvent));
                // returning the view the previous screen (Event list) instead of logging the user out.
                getActivity().onBackPressed();
            }
        });

        return view;
    }

}