package com.snhu.cs360.banddatabase;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;

public class ListFragment extends Fragment implements DetailsFragment.EventListener {

    private EventAdapter adapter;

    SimpleDateFormat formatter = new SimpleDateFormat("M/dd/yyyy");
    @Override
    public void handleEdited(Event original, Event edited) {
        adapter.editEvent(original, edited);
    }

    @Override
    public void handleDeleted(Event deleted) {
        adapter.deleteEvent(deleted);
    }

    // For the activity to implement
    public interface OnEventSelectedListener {
        void onEventSelected(int eventId);
    }

    // Reference to the activity
    private OnEventSelectedListener mListener;

    public ListFragment(){
        DetailsFragment.register(this);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnEventSelectedListener) {
            mListener = (OnEventSelectedListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnEventSelectedListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_list, container, false);

        // getting the layout and view
        RecyclerView recyclerView = view.findViewById(R.id.event_recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        // Send events to recycler view
        adapter = new EventAdapter();
        recyclerView.setAdapter(adapter);

        // action button to allow new events to be added
        FloatingActionButton fab = view.findViewById(R.id.floating_action_button);

        fab.setOnClickListener(l -> {
            AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
            builder.setTitle("Add Event");

            // calling the screen/ layout with the fields to add a new Event.
            View editView = inflater.inflate(R.layout.event_details, null);
            builder.setView(editView);

            // fields to edit by user and setting them to a variables
            EditText txtDescription = editView.findViewById(R.id.txtDescription);
            EditText txtName = editView.findViewById(R.id.txtName);
            DatePicker txtDate = editView.findViewById(R.id.datePicker);

            // Positive button OK to save entered fields to data base as a new event.
            builder.setPositiveButton("OK", (dialogInterface, i) -> {
                String name = txtName.getText().toString();
                String description = txtDescription.getText().toString();
                int dateMonth = txtDate.getMonth();
                int dateDay = txtDate.getDayOfMonth();
                int dateYear = txtDate.getYear();
                String date = String.valueOf(dateMonth + 1) + " - " + String.valueOf(dateDay) + " - " + String.valueOf(dateYear);
                Event event = new Event(name, description, date);
                long result = EventsDatabase.getInstance(getContext()).addEvent(event);

                // Checking to make sure no duplicate events are made. Adding event if no event is already found.
                if (result == -1) {
                    Toast.makeText(getContext(), "Event name already exists", Toast.LENGTH_SHORT).show();
                } else {
                    adapter.addEvent(new Event(result, event));
                }
            });

            builder.setNegativeButton("Cancel", null);
            builder.create();

            builder.show();
        });

        return view;

    }
    // recycler view of the events on the layout for list item event.
    private class EventHolder extends RecyclerView.ViewHolder
            implements View.OnClickListener {

        private Event mEvent;

        private final TextView mNameTextView;

        // calling the inflator for this view to be shown with the Event name only displayed
        public EventHolder(LayoutInflater inflater, ViewGroup parent) {
            super(inflater.inflate(R.layout.list_item_event, parent, false));
            itemView.setOnClickListener(this);
            mNameTextView = itemView.findViewById(R.id.lblEventName);
        }
        // getting the event name
        public void bind(Event event) {
            mEvent = event;
            mNameTextView.setText(mEvent.getName());
        }

        @Override
        public void onClick(View view) {
            // Tell ListActivity what event was clicked
            mListener.onEventSelected((int) mEvent.getId());
        }
    }

    private class EventAdapter extends RecyclerView.Adapter<EventHolder> {

        private final List<Event> mEvents;
        // allows notifications to be sent to the user in a Toast message if the event date matches the
        // current data and the user has notifications enabled.
        public EventAdapter() {
            mEvents = EventsDatabase.getInstance(getContext()).getEvents();

            // bool if the notifications are enabled
            boolean notificationEnabled = EventsDatabase.getInstance(getContext()).getNotification();

            Date date = new Date();
            // changing the formatting
            String newDate = formatter.format(date);
            newDate = newDate.replace("/", " - ");

            //checking the previous bool to see if user enabled notifications
            if (notificationEnabled)
            {
                for (Event element : mEvents){
                    // if statement to check dates of each saved event for that individual user to display a
                    // notification if the date matches the current date
                    if (element.getDate().contains(newDate))
                    {
                        String eventName = "Reminder you have an event named " + element.getName() + " today";
                        Toast.makeText(getContext(), eventName, Toast.LENGTH_SHORT).show();
                    }
                }
            }
        }

        @Override
        public EventHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            LayoutInflater layoutInflater = LayoutInflater.from(getActivity());
            return new EventHolder(layoutInflater, parent);
        }

        @Override
        public void onBindViewHolder(EventHolder holder, int position) {
            Event event = mEvents.get(position);
            holder.bind(event);
        }

        @Override
        public int getItemCount() {
            return mEvents.size();
        }

        public void addEvent(Event event){
            mEvents.add(event);
            notifyItemInserted(mEvents.size() - 1);
        }

        public void editEvent(Event original, Event edited) {
            int index = mEvents.indexOf(original);

            if (index >= 0) {
                mEvents.add(index, edited);
                mEvents.remove(original);
                notifyItemChanged(index);
            }
        }

        public void deleteEvent(Event event) {
            int index = mEvents.indexOf(event);
            if (index >= 0) {
                mEvents.remove(event);
                notifyItemRemoved(index);
            }
        }
    }
}