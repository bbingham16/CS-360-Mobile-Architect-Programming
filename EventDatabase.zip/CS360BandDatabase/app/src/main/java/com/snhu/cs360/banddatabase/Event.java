package com.snhu.cs360.banddatabase;

import java.util.Objects;

public class Event {

    private long id;
    private String name;
    private String description;
    private String date;

    // Getting the ID, name, description, and date and setting each of them
    public long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }

    public String getDate() {
        return date;
    }
    public void setDate(String date) {
        this.date = date;
    }

    //Constructor
    public Event(long id, String name, String description, String date) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.date = date;
    }

    public Event(String name, String description, String date){
        this(-1, name, description, date);
    }

    public Event(long id, Event event){
        this(id, event.name, event.description, event.date);
    }

    public Event(Event b) {
        this(b.id, b.name, b.description, b.date);
    }

    // checker for making sure all fields are matching
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Event event = (Event) o;
        return id == event.id && Objects.equals(name, event.name) && Objects.equals(description, event.description) && Objects.equals(date, event.date);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, name, description, date);
    }
}