package com.snhu.cs360.banddatabase;

public class UserCredentials {
    private String username;
    private String password;

    public String getUserNameCredentials() {
        return username;
    }

    public String getUserPasswordCredentials() {
        return password;
    }

    // container for storing username and password as entered by the user.
    public UserCredentials(String name, String password) {
        this.username = name;
        this.password = password;
    }
}