package com.snhu.cs360.banddatabase;

import static java.security.AccessController.getContext;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.button.MaterialButton;

public class MainActivity extends AppCompatActivity
{
    private int SMS_PERMISSION_CODE = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView username = (TextView) findViewById(R.id.username);
        TextView password = (TextView) findViewById(R.id.password);

        Button loginbtn = (MaterialButton) findViewById(R.id.loginbtn);
        Button createaccountbtn = (MaterialButton) findViewById(R.id.createaccountbtn);

        // username admin and password admin
        loginbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                // getting user input for password and username
                UserCredentials userCredentialsName = new UserCredentials(username.getText().toString(), password.getText().toString());

                // checking to make sure all fields are filled in and not blank
                if (userCredentialsName.getUserNameCredentials().equals("") || userCredentialsName.getUserPasswordCredentials().equals("")){
                    Toast.makeText(MainActivity.this, "Missing input!", Toast.LENGTH_SHORT).show();
                }
                else{
                    // Bool to check if password matches username in database.
                    Boolean checkUserLogin = EventsDatabase.getInstance(view.getContext()).checkUsernamePassword(userCredentialsName);
                    if (checkUserLogin == true){
                        Toast.makeText(MainActivity.this, "LOGIN SUCCESSFUL", Toast.LENGTH_SHORT).show();

                        // if bool is true, user is logged in and a new intent is called for List activity (event list) is displayed.
                        AuthenticatedUser user = new AuthenticatedUser(userCredentialsName.getUserNameCredentials());
                        AuthenticatedUserManager.getInstance().setUser(user);

                        startActivity(new Intent(MainActivity.this, ListActivity.class));

                        // checking for permissions
                        if(ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED)
                        {
                            Toast.makeText(MainActivity.this, "Permission has already been granted to receive SMS notifications", Toast.LENGTH_SHORT).show();
                        }
                        else
                        {
                            //requesting permissions
                            requestTextPermission();
                        }
                    }
                    else
                    {
                        //incorrect login
                        Toast.makeText(MainActivity.this, "LOGIN FAILED", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
        createaccountbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                // getting user input for password and username
                UserCredentials userCredentialsName = new UserCredentials(username.getText().toString(), password.getText().toString());

                // checking to make sure all fields are filled in and not blank
                if (userCredentialsName.getUserNameCredentials().equals("") || userCredentialsName.getUserPasswordCredentials().equals("")){
                    Toast.makeText(MainActivity.this, "Missing fields", Toast.LENGTH_SHORT).show();
                }
                else{
                    Boolean checkUser = EventsDatabase.getInstance(view.getContext()).checkUsername(userCredentialsName);
                    // if the username is not already in the database then a new user is added to the database
                    if (checkUser == false){
                        Boolean addUser = EventsDatabase.getInstance(view.getContext()).addNewUser(userCredentialsName);
                        // user is informed their account has been added and prompted to login
                        if (addUser == true){
                            Toast.makeText(MainActivity.this, "New Account Added! Please login.", Toast.LENGTH_SHORT).show();
                        }
                        // notifying the user that the account was not added
                        else{
                            Toast.makeText(MainActivity.this, "New account creation failed! Please try again.", Toast.LENGTH_SHORT).show();
                        }
                    }
                    // telling user that username already exists
                    else{
                        Toast.makeText(MainActivity.this, "Username already exists! Please choose a new username.", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }


    // Requesting permissions to sent text message notifications
    // Although not a requirement of the Professors rubric he created, it was a requirement of SNHU's rubric so I left it in my code.
    private void requestTextPermission()
    {
        if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.SEND_SMS))
        {
            new AlertDialog.Builder(this)
                    .setTitle("Permission needed")
                    .setMessage("This permission is needed to send notifications of events")
                    .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which)
                        {
                            ActivityCompat.requestPermissions(MainActivity.this, new String[] {Manifest.permission.SEND_SMS},SMS_PERMISSION_CODE);

                        }
                    })
                    .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    })
                    .create().show();
        }
        else
        {
            ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.SEND_SMS},SMS_PERMISSION_CODE);
        }
    }

    //verifying user choice for accepting or denying permissions with a small toast message.
    @SuppressLint("MissingSuperCall")
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == SMS_PERMISSION_CODE)
        {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                Toast.makeText(this, "Permission GRANTED", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Permission DENIED", Toast.LENGTH_SHORT).show();
            }
        }
    }
}