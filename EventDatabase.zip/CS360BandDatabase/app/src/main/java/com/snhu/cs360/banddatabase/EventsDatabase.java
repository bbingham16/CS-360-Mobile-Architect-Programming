package com.snhu.cs360.banddatabase;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.text.LoginFilter;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class EventsDatabase extends SQLiteOpenHelper {

    private static final int VERSION = 1;
    private static final String DATABASE_NAME = "eventLatestDB29.db";

    private static EventsDatabase instance;

    private EventsDatabase(Context context){
        super(context, DATABASE_NAME, null, VERSION);
    }

    public static EventsDatabase getInstance(Context context){
        if (instance == null){
            instance = new EventsDatabase(context);
        }

        return instance;
    }

    private static final class EventsTable {
        private static final String TABLE = "events";
        private static final String COL_ID = "_id";
        private static final String COL_NAME = "name";
        private static final String COL_DESCRIPTION = "description";
        private static final String COL_DATE = "date";

        private static final String COL_USERNAME = "username";
    }
    private static final class LoginTable {
        private static final String TABLE = "login";
        private static final String COL_USERNAME = "username";
        private static final String COL_PASSWORD = "password";
        private static final String COL_NOTIFICATIONS = "notifications";

    }

    @Override
    public void onCreate(SQLiteDatabase db){
        db.execSQL("create table " + EventsTable.TABLE + "( " +
                EventsTable.COL_ID + " integer primary key autoincrement, " +
                EventsTable.COL_NAME + ", " +
                EventsTable.COL_DESCRIPTION + ", " +
                EventsTable.COL_DATE + ", " +
                EventsTable.COL_USERNAME + ", " +
                "unique(" + EventsTable.COL_NAME + ", " +
                EventsTable.COL_DESCRIPTION + ", " +
                EventsTable.COL_DATE + "))");

        db.execSQL("create table " + LoginTable.TABLE + "( " +
                LoginTable.COL_USERNAME + " TEXT primary key, " +
                LoginTable.COL_PASSWORD + ", " +
                LoginTable.COL_NOTIFICATIONS + " integer )");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + EventsTable.TABLE);
        onCreate(db);
    }

    public List<Event> getEvents(){
        List<Event> events = new ArrayList<>();

        SQLiteDatabase db = getReadableDatabase();

        String sql = "SELECT * FROM " + EventsTable.TABLE + " WHERE " + EventsTable.COL_USERNAME + " = ?";

        Cursor cursor = db.rawQuery(sql, new String[] {AuthenticatedUserManager.getInstance().getUser().getUsername()});

        if (cursor.moveToFirst()){
            do {
                long id = cursor.getInt(0);
                String name = cursor.getString(1);
                String description = cursor.getString(2);
                String date = cursor.getString(3);
                Event event = new Event(id, name, description, date);
                events.add(event);
            } while (cursor.moveToNext());
        }

        return events;
    }

    public Event getEvent(long eventId){
        Event event = null;

        SQLiteDatabase db = getReadableDatabase();
        String sql = "SELECT * FROM " + EventsTable.TABLE + " WHERE " + EventsTable.COL_ID + " = ?";
        Cursor cursor = db.rawQuery(sql, new String[]{Long.toString(eventId)});

        if (cursor.moveToFirst()){

            String name = cursor.getString(1);
            String description = cursor.getString(2);
            String date = cursor.getString(3);
            event = new Event(eventId, name, description, date);
        }

        return event;
    }

    public long addEvent(Event event){

        SQLiteDatabase db = getWritableDatabase();


        ContentValues values = new ContentValues();
        values.put(EventsTable.COL_NAME, event.getName().trim());
        values.put(EventsTable.COL_DESCRIPTION, event.getDescription().trim());
        values.put(EventsTable.COL_DATE, event.getDate().trim());
        values.put(EventsTable.COL_USERNAME, AuthenticatedUserManager.getInstance().getUser().getUsername().trim());
        long newId = db.insert(EventsTable.TABLE, null, values);

        return newId;
    }
    public Boolean addNewUser(UserCredentials username)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(LoginTable.COL_USERNAME, username.getUserNameCredentials().trim());
        contentValues.put(LoginTable.COL_PASSWORD, username.getUserPasswordCredentials().trim());
        long result = db.insert(LoginTable.TABLE, null, contentValues);
        if (result == -1){
            return false;
        }
        else{
            return true;
        }
    }
    public Boolean checkUsername(UserCredentials username)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + LoginTable.TABLE + " WHERE " + LoginTable.COL_USERNAME + " = ?", new String[] {username.getUserNameCredentials()});
        if (cursor.getCount() > 0){
            return true;
        }
        else{
            return false;
        }
    }
    public Boolean checkUsernamePassword(UserCredentials username)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + LoginTable.TABLE + " WHERE " + LoginTable.COL_USERNAME + " = ? and " + LoginTable.COL_PASSWORD + " = ?", new String[] {username.getUserNameCredentials(), username.getUserPasswordCredentials()});
        if (cursor.getCount() > 0){
            return true;
        }
        else{
            return false;
        }
    }
    public Boolean setNotification(Boolean enable)
    {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(LoginTable.COL_NOTIFICATIONS, enable ? 1:0);

        int result = db.update(LoginTable.TABLE, values,LoginTable.COL_USERNAME + " = ?", new String[]{AuthenticatedUserManager.getInstance().getUser().getUsername()});

        return result == 1;
    }
    public boolean getNotification()
    {
        SQLiteDatabase db = getReadableDatabase();
        String sql = "SELECT " + LoginTable.COL_NOTIFICATIONS + " FROM " + LoginTable.TABLE + " WHERE " + LoginTable.COL_USERNAME + " = ?";
        Cursor cursor = db.rawQuery(sql, new String[]{AuthenticatedUserManager.getInstance().getUser().getUsername()});

        boolean enabled = false;
        if (cursor.moveToFirst()){

            enabled = cursor.getInt(0) == 1;
        }
        return enabled;
    }

    public boolean editEvent(long id, Event event){
        boolean isEdited = false;
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(EventsTable.COL_ID, id);
        values.put(EventsTable.COL_NAME, event.getName());
        values.put(EventsTable.COL_DESCRIPTION, event.getDescription());
        values.put(EventsTable.COL_DATE, event.getDate());

        int result = db.update(EventsTable.TABLE, values, EventsTable.COL_ID + " = " + id, null);

        return result == 1;
    }

    public boolean deleteEvent(long id){
        SQLiteDatabase db = getWritableDatabase();

        int result = db.delete(EventsTable.TABLE, EventsTable.COL_ID + " = " + id, null);
        return result == 1;
    }
}
