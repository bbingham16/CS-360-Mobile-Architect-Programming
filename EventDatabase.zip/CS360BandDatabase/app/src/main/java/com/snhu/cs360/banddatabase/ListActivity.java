package com.snhu.cs360.banddatabase;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Switch;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

public class ListActivity extends AppCompatActivity implements ListFragment.OnEventSelectedListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        // Need to find a way to get the username that is logged in
        //Possibly pass as an intent to this class and read it in
        //NotificationsManager.initialize(getApplicationContext(), "the_Username");

        FragmentManager fragmentManager = getSupportFragmentManager();
        Fragment fragment = fragmentManager.findFragmentById(R.id.list_fragment_container);

        if (fragment == null) {
            fragment = new ListFragment();
            fragmentManager.beginTransaction()
                    .add(R.id.list_fragment_container, fragment)
                    .commit();
        }
    }
    @Override
    // menu to hold the logout option and notifications page
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.item_menu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int itemId = item.getItemId();
        // which option was selected from the menu
        if (itemId == R.id.action_notifications){
            // Notifications selected
            setContentView(R.layout.activity_notification);
            Toast.makeText(this, "Notifications selected", Toast.LENGTH_SHORT).show();
            // initiate a Switch
            Switch notifySwitch = (Switch) findViewById(R.id.notification_switch);

            notifySwitch.setOnClickListener(new View.OnClickListener() {
                @Override
                // checks to see if notifications are switched on or off to get events to populate from the database when user returns
                // to the list activity screen (listing the events)
                public void onClick(View view)
                {
                    Boolean switchState = notifySwitch.isChecked();
                    EventsDatabase.getInstance(ListActivity.this).setNotification(switchState);
                }});

            // check current state of a Switch (true or false).
            boolean notificationEnabled = EventsDatabase.getInstance(ListActivity.this).getNotification();
            notifySwitch.setChecked(notificationEnabled);

            return true;
        }
        else if (itemId == R.id.action_logout) {
            // Logout selected- logging out of the app
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    // created top allow user to use the built in back button to the events list instead of logging out
    public void onBackPressed() {
        super.onBackPressed();
        Intent intent = new Intent(this, ListActivity.class);
        startActivity(intent);
    }


    @Override
    public void onEventSelected(int eventId) {
        // Send the event ID of the clicked button to DetailsActivity
        Intent intent = new Intent(this, DetailsActivity.class);
        intent.putExtra(DetailsActivity.EXTRA_EVENT_ID, eventId);
        startActivity(intent);
    }
}