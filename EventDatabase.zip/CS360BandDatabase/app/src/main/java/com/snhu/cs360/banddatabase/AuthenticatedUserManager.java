package com.snhu.cs360.banddatabase;

public class AuthenticatedUserManager {

    private AuthenticatedUser user;
    // creating an instance for AuthenticatedUserManager
    private static AuthenticatedUserManager instance;

    private AuthenticatedUserManager(){}
    // getting the instance
    public static AuthenticatedUserManager getInstance(){
        if (instance == null){
            // creating a new instance if instance is already null
            instance = new AuthenticatedUserManager();
        }
        return instance;
    }
    //creating a getter for AuthenticatedUser
    public AuthenticatedUser getUser(){
        return user;
    }
    //creating a setter for AuthenticatedUser
    public void setUser(AuthenticatedUser user){
        this.user = user;
    }
}
