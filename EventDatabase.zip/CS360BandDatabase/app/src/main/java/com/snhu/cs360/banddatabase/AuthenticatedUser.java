package com.snhu.cs360.banddatabase;

public class AuthenticatedUser {
    private String username;

    //Creating a getter for username
    public AuthenticatedUser(String username) {
        this.username = username;
    }

    public String getUsername() {
        return username;
    }
}
